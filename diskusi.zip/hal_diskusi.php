<?php
if (isset($_GET['id'])) {
    // tampilkan detail berita
    $sqlDetail = mysqli_query($konek, "SELECT berita.*,kategori.nm_kategori,user.nama_lengkap
            FROM berita INNER JOIN kategori ON berita.id_kategori=kategori.id 
            INNER JOIN user ON berita.id_user=user.id
            WHERE berita.id='$_GET[id]'");
    $dbrt = mysqli_fetch_array($sqlDetail);
?>
    <section class="diskusi" style="margin-top: 120px;">
        <div class="container">
            <div class="judul">
                <a href="./?hal=diskusi&ktg=<?= $dbrt['id_kategori']; ?>" class="warning"><?= $dbrt['nm_kategori']; ?></a>
                <h4 style="font-weight: bold;"><?= $dbrt['judul']; ?></h4>
                <hr>
            </div>
            <div class="profile d-flex  align-items-center justify-content-between">
                <div class="user d-flex  align-items-center">
                    <img src="images/foto.png" alt="foto" width="100px" class="me-3">
                    <div class="name">
                        <p style="margin-bottom: 1px; font-weight: bold;"><?= $dbrt['nama_lengkap']; ?></p>
                        <span style="color: rgba(86, 86, 86, 0.667);"><?= $dbrt['tgl']; ?></span>
                    </div>
                </div>

                <div class="dropdown">
                    <a class="cursor-pointer link-dark" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="uil uil-ellipsis-v more"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end px-2 py-3 me-sm-n4" aria-labelledby="dropdownMenuButton1">
                        <li><a class="dropdown-item" href="#">Edit</a></li>
                        <li><a class="dropdown-item" href="#">Laporkan</a></li>
                    </ul>
                </div>
            </div>

            <div class="content">
                <?= $dbrt['isi']; ?>
            </div>
            <hr>
            <div class="d-flex justify-content-end">
                <button class="btn link-light" data-bs-toggle="collapse" data-bs-target="" aria-expanded="false" aria-controls="collapseExample" style="background-color: #960909;">Diskusi</button>
            </div>

            <section class="komentar " id="">
                <div class="container mt-3" style="width: 100%;box-shadow: none;background-color: #eee">
                    <h5 class="mb-4 fw-bold" style="color: #960909;">Diskusi</h5>
                    <?php
                    $sqlKomen = mysqli_query($konek, "SELECT * FROM komentar WHERE id_berita='$dbrt[id]' ORDER BY id DESC");
                    while ($dk = mysqli_fetch_array($sqlKomen)) {
                    ?>
                        <div class="pesan d-flex mb-4">
                            <div class="text bg-light pt-2 ps-2 pe-2 rounded" style="width: 100%;">

                                <p class="mb-1 fw-bold" style="font-size: 14px;"><?= $dk['nama'] ?></p>
                                <p style="font-size: 12px; text-align: justify;"><?= $dk['komentar'] ?></p>
                                <p class="link-secondary mb-1" style="font-size: 12px;text-align: right;padding: 0;margin-top: -10px;">
                                    <?= $dk['tgl'] ?></p>
                            </div>
                        </div>
                    <?php
                    }
                    ?>

                    <!-- <div class="input-group"> -->
                    <form action="simpan_komentar.php" method="POST" class="input-group">
                        <input type="hidden" name="idberita" value="<?= $dbrt['id'] ?>">
                        <input type="hidden" name="nama" value="<?= $_SESSION['nama'] ?>">

                        <input type="text" class="form-control" placeholder="Ketik diskusi disini..." aria-label="Recipient's username" aria-describedby="button-addon2" name="komentar">
                        <button class="btn link-light " style="background-color: #960909;" type="submit" id="button-addon2"><i class="uil uil-message"></i></button>
                    </form>
                    <!-- </div> -->
                </div>
            </section>
        </div>
    </section>
    <!-- footer -->
    <footer>
        <center>
            <img src="images/logo2.png" alt="logo" width="200px">
        </center>
    </footer>
    <!-- Akhir footer -->
<?php
} elseif (isset($_GET['ktg'])) {
    // tampilkan berita berdasarkan kategori
    $sqlKtg = mysqli_query($konek, "SELECT * FROM kategori where id='$_GET[ktg]'");
    $ktg = mysqli_fetch_array($sqlKtg);
?>
    <section class="judul" style="margin-top: 150px;">
        <div class="container mt-5 bg-light p-4 shadow-sm rounded-3">
            <h3 class="fw-bold mb-4" style="color: #960909;">Diskusi - Kategori <?= $ktg['nm_kategori']; ?></h3>
            <ul>
                <?php
                $sqlBerita = mysqli_query($konek, "SELECT * FROM berita WHERE id_kategori='$_GET[ktg]' ORDER BY id DESC");
                while ($brt = mysqli_fetch_array($sqlBerita)) {
                    echo "
                        <li class='py-1'>
                            <a href='./?hal=diskusi&id=$brt[id]' class='text-decoration-none link-dark'>$brt[judul]</a>
                        </li>";
                }
                ?>
            </ul>
        </div>
    </section>
    <!-- footer -->
    <footer>
        <center>
            <img src="images/logo2.png" alt="logo" width="200px">
        </center>
    </footer>
    <!-- Akhir footer -->
<?php
} else {
    // tampilkan daftar berita
?>

<?php } ?>