<?php
session_start();
include "../../../inc/config.php";
if (!empty($_POST['username']) && !empty($_POST['password']) && !empty($_POST['nama']) && !empty($_POST['email']) && !empty($_POST['notelp'])) {
    // proses insert diskusi
    $password = md5($_POST['password']);
    mysqli_query($konek, "INSERT INTO user (username,password,nama_lengkap,email,telp,level,aktif) VALUES 
    ('$_POST[username]','$password','$_POST[nama]','$_POST[email]','$_POST[notelp]','$_POST[level]','$_POST[aktif]')");
    header('Location:../dashboard.php?m=user');
} else {
    header('Location:../dashboard.php?m=user');
    echo "<script>alert('Pastikan Semua Data Terisi!!');</script>";
}
// session_start();
// include "../../../inc/config.php";
// if (!empty($_POST['judul'])) {
//     $tgl = date("Y-m-d");
//     $iduser = $_SESSION['id'];
//     mysqli_query($konek, "insert into berita (id_kategori, judul, isi, tgl,id_user) values ('$_POST[kategori]','$_POST[judul],'$_POST[isi]', '$tgl', '$iduser')");
//     header('Location:../dashboard.php?m=diskusi');
// } else {
//     header('Location:../dashboard.php?m=diskusi');
// }
