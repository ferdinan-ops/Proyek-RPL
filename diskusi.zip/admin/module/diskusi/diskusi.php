<?php
if (isset($_GET['tipe'])) {
    if ($_GET['tipe'] == 'tambah') {
        echo "
        <section class='posting mt-4'>
            <h5 class='fw-bold' style='color: maroon;'>Tulis Posting Diskusi Baru</h5>
            <hr>
            <form method='post' action='diskusi/proses_tambah.php'>
                <div class='my-3'>
                    <label for='judul' class='form-label'>Judul Diskusi</label>
                    <input type='text' class='form-control' name='judul' placeholder='Masukkan Judul Diskusi'>
                </div>
                <div class='my-3'>
                    <label for='kategori' class='mb-2'>Kategori Diskusi</label>
                    <select class='form-select' name='kategori'>
                    ";
        $sql = mysqli_query($konek, "SELECT * FROM kategori ORDER BY nm_kategori ASC");
        while ($k = mysqli_fetch_array($sql)) {
            echo "<option value='$k[id]'>$k[nm_kategori]</option>";
        };
        echo "
                    </select>
                </div>
                <div class='my-3'>
                    <label for='diskusi' class='mb-2'>Isi Diskusi</label>
                    <textarea class='form-control summernote' name='isi'></textarea>
                </div>
                <input type='submit' class='btn link-light my-3' style='background-color: maroon;' value='Simpan'>
                <input type='button' class='btn link-dark bg-light my-3' value='Batal' onclick='history.back();'>
            </form>
    </section>
        ";
    } elseif ($_GET['tipe'] == 'edit') {
        $sql = mysqli_query($konek, "SELECT * FROM berita WHERE id='$_GET[id]'");
        $de = mysqli_fetch_array($sql);
        echo "
        <section class='f-berita mt-4'>
            <h5 class='fw-bold' style='color: maroon;'>Edit Diskusi</h5>
            <hr>
            <form method='post' action='diskusi/proses_edit.php'>
            <input type='hidden' name='id' value='$de[id]'>
            <div class='my-3'>
            <label for='judul' class='form-label'>Judul Diskusi</label>
            <input type='text' class='form-control' name='judul' placeholder='Masukkan Judul Diskusi' value='$de[judul]'>
        </div>
        <div class='my-3'>
            <label for='kategori' class='mb-2'>Kategori Diskusi</label>
            <select class='form-select' name='kategori'>
            ";
        $sql = mysqli_query($konek, "SELECT * FROM kategori ORDER BY nm_kategori ASC");
        while ($k = mysqli_fetch_array($sql)) {
            echo "<option value='$k[id]'>$k[nm_kategori]</option>";
        };
        echo "
            </select>
        </div>
        <div class='my-3'>
            <label for='diskusi' class='mb-2'>Isi Diskusi</label>
            <textarea class='form-control summernote' name='isi' >$de[isi]</textarea>
        </div>
                <label>&nbsp;</label>
                <input type='submit' class='btn link-light my-3' style='background-color: maroon;' value='Update'>
                <input type='button' class='btn link-dark bg-light my-3' value='Batal' onClick='history.back();'>
            </form>
    </section>
    ";
    }
} else {
?>
    <h1 class="mt-4">Diskusi</h1>
    <a href="?m=diskusi&tipe=tambah"><button class="btn mb-4 link-light mt-4" type="button" style="background-color: #960909;">
            <i class="uil uil-plus"></i> Tambah Diskusi</button></a>
    <table class="table table-striped" style="width:  100%; text-align: center;">
        <thead></thead>
        <thead>
            <tr>
                <th scope="col">No</th>
                <th scope="col">Judul</th>
                <th scope="col">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $sql = mysqli_query($konek, "SELECT*FROM berita ORDER BY judul asc");
            $no = 1;
            while ($k = mysqli_fetch_array($sql)) {
                echo "<tr>
                    <td>$no</td>
                    <td>$k[judul]</td>
                    <td>
                        <a href='?m=diskusi&tipe=edit&id=$k[id]' class='btn btn-primary'>Edit</a>
                        <a onclick='confirm(\"Anda yakin akan menghapus?\")' href='diskusi/proses_hapus.php?id=$k[id]' class='btn btn-danger'>Hapus</a>
                    </td>
                </tr>";
                $no++;
            }
            ?>
        </tbody>
    </table>
<?php } ?>